from Ingreso import InterfazLogin
from ControlUsuarios import InterfazControlUsuarios

def lanzar_formulario_principal():
    InterfazControlUsuarios()

if __name__ == "__main__":
    app_login = InterfazLogin(al_ingresar_exitoso=lanzar_formulario_principal)
    app_login.arrancar()
