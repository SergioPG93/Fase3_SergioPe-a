class EstructuraPila:
    def __init__(self):
        self.elementos = []
    def apilar(self, elemento):
        self.elementos.append(elemento)
    def desapilar(self):
        return self.elementos.pop() if self.elementos else None
    def obtener_total_tarifas(self):
        return sum(item.tarifa_afiliacion for item in self.elementos)

class EstructuraCola:
    def __init__(self):
        self.elementos = []
    def encolar(self, elemento):
        self.elementos.append(elemento)
    def desencolar(self):
        return self.elementos.pop(0) if self.elementos else None
    def obtener_cantidad(self):
        return len(self.elementos)

class EstructuraLista:
    def __init__(self):
        self.elementos = []
    def agregar(self, elemento):
        self.elementos.append(elemento)
    def eliminar_por_id(self, numero_id):
        for idx, item in enumerate(self.elementos):
            if item.numero_id == numero_id:
                return self.elementos.pop(idx)
        return None
    def obtener_promedio_ingresos(self):
        if not self.elementos: return 0.0
        return sum(item.ingresos_actuales for item in self.elementos) / len(self.elementos)
