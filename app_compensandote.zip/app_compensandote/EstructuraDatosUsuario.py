class AfiliadoUsuario:
    """Representa la estructura de datos de un cliente de la Caja."""
    def __init__(self, tipo_id, numero_id, nombre_completo, ingresos_actuales, tipo_empleo, servicio_deseado, fecha_afiliacion):
        self.tipo_id = tipo_id
        self.numero_id = numero_id
        self.nombre_completo = nombre_completo
        self.ingresos_actuales = float(ingresos_actuales)
        self.tipo_empleo = tipo_empleo
        self.servicio_deseado = servicio_deseado
        self.fecha_afiliacion = fecha_afiliacion
        self.tarifa_afiliacion = self.calcular_tarifa_final()

    def calcular_tarifa_final(self):
        ingresos = self.ingresos_actuales
        tarifa_base = 0.0
        
        # Rango de tarifas para empleados e independientes (Tablas 2 y 3)
        if self.tipo_empleo == "Empleado":
            if 1000000 <= ingresos <= 2000000: tarifa_base = 45000.0
            elif 2000000 < ingresos <= 3000000: tarifa_base = 60000.0
            elif 3000000 < ingresos <= 4000000: tarifa_base = 75000.0
            elif 4000000 < ingresos <= 5000000: tarifa_base = 90000.0
            elif ingresos > 5000000: tarifa_base = 150000.0
        else: # Independiente
            if 1000000 <= ingresos <= 2000000: tarifa_base = 10000.0
            elif 2000000 < ingresos <= 3000000: tarifa_base = 20000.0
            elif 3000000 < ingresos <= 4000000: tarifa_base = 30000.0
            elif 4000000 < ingresos <= 5000000: tarifa_base = 40000.0
            elif ingresos > 5000000: tarifa_base = 80000.0

        # Adiciones por servicio seleccionado
        if self.servicio_deseado == "Ingreso a parque":
            tarifa_base += 2500.0
        elif self.servicio_deseado == "Curso de formación":
            tarifa_base += 7500.0
        elif self.servicio_deseado == "Paquete de viaje":
            tarifa_base += 10000.0
        elif self.servicio_deseado == "Medicina preventiva":
            tarifa_base += (ingresos * 0.10)
            
        return tarifa_base
