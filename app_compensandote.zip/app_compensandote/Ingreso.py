import tkinter as tk
from tkinter import messagebox

class InterfazLogin:
    def __init__(self, al_ingresar_exitoso):
        self.al_ingresar = al_ingresar_exitoso
        self.bg_pastel = "#FAFAFA"
        self.salmon_pastel = "#FFA07A"
        self.azul_pastel = "#AED6F1"
        self.coral_pastel = "#F5B7B1"
        
        self.raiz = tk.Tk()
        self.raiz.title("Login - Compensándote")
        self.raiz.geometry("400x250")
        self.raiz.resizable(False, False)
        self.raiz.configure(bg=self.bg_pastel)
        
        self.crear_componentes()
        
    def crear_componentes(self):
        tk.Label(self.raiz, text="Caja Compensándote App", font=("Arial", 16, "bold"), bg=self.bg_pastel, fg="#E26A45").pack(pady=15)
        tk.Label(self.raiz, text="Digite la Contraseña del Sistema:", bg=self.bg_pastel, fg="#555555").pack(pady=5)
        
        self.entrada_password = tk.Entry(self.raiz, show="*", width=25, font=("Arial", 11))
        self.entrada_password.pack(pady=5)

        marco_botones = tk.Frame(self.raiz, bg=self.bg_pastel)
        marco_botones.pack(pady=20)

        tk.Button(marco_botones, text="Ingresar", width=10, bg=self.salmon_pastel, relief="flat", command=self.procesar_login).grid(row=0, column=0, padx=5)
        tk.Button(marco_botones, text="Acerca de", width=10, bg=self.azul_pastel, relief="flat", command=self.mostrar_acerca_de).grid(row=0, column=1, padx=5)
        tk.Button(marco_botones, text="Salir", width=10, bg=self.coral_pastel, relief="flat", command=self.raiz.quit).grid(row=0, column=2, padx=5)

    def mostrar_acerca_de(self):
        info_msg = (
            "Curso: Estructura de Datos - 301305\n"
            "Estudiante: Sergio Hernan Peña Guzman\n"
            "Grupo Colaborativo: 301305_274\n"
            "Institución: UNAD\n"
            "Fecha: Octubre 2026"
        )
        messagebox.showinfo("Acerca de la Aplicación", info_msg)

    def procesar_login(self):
        if self.entrada_password.get() == "Caja":
            self.raiz.destroy()
            self.al_ingresar()
        else:
            messagebox.showerror("Acceso Denegado", "La contraseña ingresada es incorrecta.")
            
    def arrancar(self):
        self.raiz.mainloop()
