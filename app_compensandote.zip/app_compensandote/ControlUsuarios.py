import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
from EstructuraDatosUsuario import AfiliadoUsuario
from Estructuras import EstructuraPila, EstructuraCola, EstructuraLista

class InterfazControlUsuarios:
    def __init__(self):
        self.pila = EstructuraPila()
        self.cola = EstructuraCola()
        self.lista = EstructuraLista()
        
        self.bg_pastel = "#FAFAFA"
        self.salmon_pastel = "#FFA07A"
        self.menta_pastel = "#A3E4D7"
        self.amarillo_pastel = "#F9E79F"
        self.coral_pastel = "#F5B7B1"
        self.azul_pastel = "#AED6F1"
        
        self.ventana_principal = tk.Tk()
        self.ventana_principal.title("Caja Compensándote – Control de Afiliados")
        self.ventana_principal.geometry("980x600")
        self.ventana_principal.configure(bg=self.bg_pastel)
        
        self.crear_componentes()
        self.actualizar_tabla_vista()
        self.ventana_principal.mainloop()

    def crear_componentes(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview.Heading", background=self.salmon_pastel, foreground="black", font=("Arial", 9, "bold"))
        style.configure("Treeview", background="white", fieldbackground="white", rowheight=24)

        marco_formulario = tk.LabelFrame(self.ventana_principal, text=" Formulario de Información del Afiliado ", bg=self.bg_pastel, font=("Arial", 10, "bold"), padx=10, pady=10)
        marco_formulario.pack(side=tk.LEFT, fill=tk.Y, padx=15, pady=15)

        tk.Label(marco_formulario, text="Tipo Identificación:", bg=self.bg_pastel).grid(row=0, column=0, sticky="w", pady=4)
        self.cb_tipo_id = ttk.Combobox(marco_formulario, values=["CC", "CE", "NUIP", "PAS"], state="readonly", width=22)
        self.cb_tipo_id.grid(row=0, column=1, pady=4)
        self.cb_tipo_id.current(0)

        tk.Label(marco_formulario, text="Número Identificación:", bg=self.bg_pastel).grid(row=1, column=0, sticky="w", pady=4)
        self.entry_numero_id = tk.Entry(marco_formulario, width=25)
        self.entry_numero_id.grid(row=1, column=1, pady=4)

        tk.Label(marco_formulario, text="Nombre Completo:", bg=self.bg_pastel).grid(row=2, column=0, sticky="w", pady=4)
        self.entry_nombre = tk.Entry(marco_formulario, width=25)
        self.entry_nombre.grid(row=2, column=1, pady=4)

        tk.Label(marco_formulario, text="Ingresos Actuales ($):", bg=self.bg_pastel).grid(row=3, column=0, sticky="w", pady=4)
        self.entry_ingresos = tk.Entry(marco_formulario, width=25)
        self.entry_ingresos.grid(row=3, column=1, pady=4)
        self.entry_ingresos.bind("<KeyRelease>", lambda event: self.evento_calcular_tarifa())

        tk.Label(marco_formulario, text="Tipo de Empleo:", bg=self.bg_pastel).grid(row=4, column=0, sticky="w", pady=4)
        self.radio_var = tk.StringVar(value="Empleado")
        marco_radio = tk.Frame(marco_formulario, bg=self.bg_pastel)
        marco_radio.grid(row=4, column=1, sticky="w")
        tk.Radiobutton(marco_radio, text="Empleado", variable=self.radio_var, value="Empleado", bg=self.bg_pastel, command=self.evento_calcular_tarifa).pack(side=tk.LEFT)
        tk.Radiobutton(marco_radio, text="Independiente", variable=self.radio_var, value="Independiente", bg=self.bg_pastel, command=self.evento_calcular_tarifa).pack(side=tk.LEFT)

        tk.Label(marco_formulario, text="Servicio Deseado:", bg=self.bg_pastel).grid(row=5, column=0, sticky="w", pady=4)
        self.cb_servicio = ttk.Combobox(marco_formulario, values=["Subsidio de desempleo", "Ingreso a parque", "Curso de formación", "Paquete de viaje", "Medicina preventiva"], state="readonly", width=22)
        self.cb_servicio.grid(row=5, column=1, pady=4)
        self.cb_servicio.current(0)
        self.cb_servicio.bind("<<ComboboxSelected>>", lambda event: self.evento_calcular_tarifa())

        tk.Label(marco_formulario, text="Tarifa Calculada ($):", bg=self.bg_pastel).grid(row=6, column=0, sticky="w", pady=4)
        self.entry_tarifa = tk.Entry(marco_formulario, width=25, state="disabled", disabledbackground="#EAECEE", fg="black")
        self.entry_tarifa.grid(row=6, column=1, pady=4)

        tk.Label(marco_formulario, text="Fecha (DD/MM/AAAA):", bg=self.bg_pastel).grid(row=7, column=0, sticky="w", pady=4)
        self.entry_fecha = tk.Entry(marco_formulario, width=25)
        self.entry_fecha.grid(row=7, column=1, pady=4)
        self.entry_fecha.insert(0, datetime.now().strftime("%d/%m/%Y"))

        tk.Label(marco_formulario, text="Estructura Destino:", bg=self.bg_pastel).grid(row=8, column=0, sticky="w", pady=10)
        self.cb_estructura = ttk.Combobox(marco_formulario, values=["Pila", "Cola", "Lista"], state="readonly", width=22)
        self.cb_estructura.grid(row=8, column=1, pady=10)
        self.cb_estructura.current(0)
        self.cb_estructura.bind("<<ComboboxSelected>>", lambda event: self.actualizar_tabla_vista())

        tk.Button(marco_formulario, text="Registrar Afiliado", bg=self.menta_pastel, relief="flat", width=22, font=("Arial", 9, "bold"), command=self.registrar_afiliado).grid(row=9, column=0, columnspan=2, pady=6)
        tk.Button(marco_formulario, text="Limpiar Campos", bg=self.amarillo_pastel, relief="flat", width=22, font=("Arial", 9, "bold"), command=self.limpiar_formulario).grid(row=10, column=0, columnspan=2, pady=4)
        tk.Button(marco_formulario, text="Eliminar / Retirar Registro", bg=self.coral_pastel, relief="flat", width=22, font=("Arial", 9, "bold"), command=self.eliminar_registro).grid(row=11, column=0, columnspan=2, pady=4)

        marco_vista = tk.Frame(self.ventana_principal, bg=self.bg_pastel)
        marco_vista.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=15, pady=15)

        self.lbl_titulo_tabla = tk.Label(marco_vista, text="Estructura Activa: Registros en Pila", bg=self.bg_pastel, font=("Arial", 12, "bold"), fg="#333333")
        self.lbl_titulo_tabla.pack(anchor="w", pady=5)

        columnas = ("tipo_id", "num_id", "nombre", "ingresos", "empleo", "servicio", "tarifa", "fecha")
        self.tree = ttk.Treeview(marco_vista, columns=columnas, show="headings")
        
        encabezados = ["Tipo ID", "Número ID", "Nombre Completo", "Ingresos", "Contexto Laboral", "Servicio", "Tarifa", "Fecha"]
        for col, h_name in zip(columnas, encabezados):
            self.tree.heading(col, text=h_name)
            self.tree.column(col, width=95, anchor="center")
        self.tree.pack(fill=tk.BOTH, expand=True)

        marco_reporte = tk.LabelFrame(marco_vista, text=" Reporte Técnico del Sistema ", bg=self.bg_pastel, font=("Arial", 10, "bold"), pady=10, padx=10)
        marco_reporte.pack(fill=tk.X, pady=10)

        self.entry_reporte = tk.Entry(marco_reporte, width=55, state="disabled", font=("Courier New", 10, "bold"), disabledbackground="white")
        self.entry_reporte.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        tk.Button(marco_reporte, text="Ver Reporte", bg=self.azul_pastel, relief="flat", width=12, font=("Arial", 9, "bold"), command=self.generar_reporte_analitico).pack(side=tk.LEFT, padx=5)
        tk.Button(marco_vista, text="Salir del Sistema", bg="#BDC3C7", relief="flat", width=15, font=("Arial", 9, "bold"), command=self.ventana_principal.quit).pack(side=tk.RIGHT, pady=5)

    def evento_calcular_tarifa(self):
        try:
            ingresos_txt = self.entry_ingresos.get()
            if not ingresos_txt: return
            sim_usuario = AfiliadoUsuario(self.cb_tipo_id.get(), "0", "Temp", ingresos_txt, self.radio_var.get(), self.cb_servicio.get(), "01/01/2026")
            self.entry_tarifa.config(state="normal")
            self.entry_tarifa.delete(0, tk.END)
            self.entry_tarifa.insert(0, f"${sim_usuario.tarifa_afiliacion:,.2f}")
            self.entry_tarifa.config(state="disabled")
        except ValueError:
            pass

    def registrar_afiliado(self):
        num_id = self.entry_numero_id.get().strip()
        nombre = self.entry_nombre.get().strip()
        ingresos_str = self.entry_ingresos.get().strip()
        fecha_str = self.entry_fecha.get().strip()

        if not (num_id and nombre and ingresos_str and fecha_str):
            messagebox.showwarning("Error de Validación", "Todos los campos del formulario son obligatorios.")
            return

        if not num_id.isdigit():
            messagebox.showwarning("Error de Validación", "El número de identificación debe contener solo dígitos.")
            return

        if not nombre.replace(" ", "").isalpha():
            messagebox.showwarning("Error de Validación", "El nombre completo debe contener solo letras.")
            return

        nuevo_afiliado = AfiliadoUsuario(self.cb_tipo_id.get(), num_id, nombre, ingresos_str, self.radio_var.get(), self.cb_servicio.get(), fecha_str)
        selected_struct = self.cb_estructura.get()
        
        if selected_struct == "Pila": self.pila.apilar(nuevo_afiliado)
        elif selected_struct == "Cola": self.cola.encolar(nuevo_afiliado)
        elif selected_struct == "Lista": self.lista.agregar(nuevo_afiliado)

        messagebox.showinfo("Registro Exitoso", f"El registro fue guardado correctamente en la {selected_struct} en memoria.")
        self.limpiar_formulario()
        self.actualizar_tabla_vista()

    def eliminar_registro(self):
        selected_struct = self.cb_estructura.get()
        if selected_struct == "Pila":
            if not self.pila.elementos: 
                messagebox.showwarning("Estructura Vacía", "La Pila no contiene registros para desapilar.")
                return
            if messagebox.askyesno("Confirmar", "¿Desea desapilar (Pop) el último registro ingresado?"):
                self.pila.desapilar()
        elif selected_struct == "Cola":
            if not self.cola.elementos: 
                messagebox.showwarning("Estructura Vacía", "La Cola no contiene registros para desencolar.")
                return
            if messagebox.askyesno("Confirmar", "¿Desea desencolar (Dequeue) el primer registro en fila?"):
                self.cola.desencolar()
        elif selected_struct == "Lista":
            id_num = self.entry_numero_id.get().strip()
            if not id_num:
                messagebox.showwarning("Dato Faltante", "Escriba el número de identificación en el campo para buscarlo y eliminarlo de la Lista.")
                return
            if messagebox.askyesno("Confirmar", f"¿Está seguro de eliminar al afiliado con ID {id_num} de la Lista?"):
                eliminado = self.lista.eliminar_por_id(id_num)
                if not eliminado:
                    messagebox.showerror("No Encontrado", "La identificación digitada no existe en la estructura Lista.")
        self.actualizar_tabla_vista()

    def generar_reporte_analitico(self):
        selected_struct = self.cb_estructura.get()
        self.entry_reporte.config(state="normal")
        self.entry_reporte.delete(0, tk.END)
        if selected_struct == "Pila":
            self.entry_reporte.insert(0, f"[REPORTE PILA]: Suma acumulada de tarifas de afiliación: ${self.pila.get_total_fees():,.2f} COP")
        elif selected_struct == "Cola":
            self.entry_reporte.insert(0, f"[REPORTE COLA]: Cantidad de registros activos en espera: {self.cola.get_count()} usuarios.")
        elif selected_struct == "Lista":
            self.entry_reporte.insert(0, f"[REPORTE LISTA]: Promedio aritmético de los ingresos actuales: ${self.lista.get_average_income():,.2f} COP")
        self.entry_reporte.config(state="disabled")

    def actualizar_tabla_vista(self):
        for row in self.tree.get_children(): self.tree.delete(row)
        selected_struct = self.cb_estructura.get()
        self.lbl_titulo_tabla.config(text=f"Estructura Activa: Registros en {selected_struct}")
        
        target = self.pila.elementos if selected_struct == "Pila" else (self.cola.elementos if selected_struct == "Cola" else self.lista.elementos)
        for item in target:
            self.tree.insert("", tk.END, values=(
                item.tipo_id, item.numero_id, item.nombre_completo, 
                f"${item.ingresos_actuales:,.2f}", item.tipo_empleo, 
                item.servicio_deseado, f"${item.tarifa_afiliacion:,.2f}", item.fecha_afiliacion
            ))
        self.generar_reporte_analitico()

    def limpiar_formulario(self):
        self.entry_numero_id.delete(0, tk.END)
        self.entry_nombre.delete(0, tk.END)
        self.entry_ingresos.delete(0, tk.END)
        self.entry_tarifa.config(state="normal")
        self.entry_tarifa.delete(0, tk.END)
        self.entry_tarifa.config(state="disabled")
        self.radio_var.set("Empleado")
        self.cb_tipo_id.current(0)
        self.cb_servicio.current(0)
        self.entry_fecha.delete(0, tk.END)
        self.entry_fecha.insert(0, datetime.now().strftime("%d/%m/%Y"))
